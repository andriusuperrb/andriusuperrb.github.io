/**
 * @module
 * @export {String} selectors
 */

export const selectors = 'scrollbar, [scrollbar], [data-scrollbar]';
