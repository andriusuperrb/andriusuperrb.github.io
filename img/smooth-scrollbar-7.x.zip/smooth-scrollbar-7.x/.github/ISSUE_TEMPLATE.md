<!--- Provide a general summary of the issue in the Title above -->

## Issue Summary
<!-- A summary of the issue and the browser/OS environment in which it occurs.  -->

## Expected Behavior
<!--- If you're describing a bug, tell me what should happen -->
<!--- If you're suggesting a change/improvement, tell me how it should work -->

## Current Behavior
<!--- If describing a bug, tell me what happens instead of the expected behavior -->

## Steps to Reproduce
<!-- Tell me how it happened -->

## Environment
- Browser:
- Version of smooth-scrollbar:

## Online demo
<!-- Create an example on jsbin.com or others -->
